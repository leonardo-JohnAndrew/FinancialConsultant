// Ang file na ito ay awtomatikong ginagamit ni Next.js (built-in hook).
// Tinatawag ito NANG ISANG BESES pagka-start ng Next.js server mo —
// dito natin sisimulan ang backup scheduler, para hindi na kailangan
// ng hiwalay na terminal/process para dito.
//
// Requirements:
// - Next.js 15+: gumagana agad ito, walang extra config
// - Next.js 13.4 - 14.x: idagdag ang { experimental: { instrumentationHook: true } }
//   sa next.config.js (tingnan ang README)

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { startDbBackupScheduler } = await import('./lib/db-backup/scheduler');
    startDbBackupScheduler();
  }
}
