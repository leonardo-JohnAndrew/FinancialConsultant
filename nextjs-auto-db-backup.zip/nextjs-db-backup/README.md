# Auto Daily MySQL Backup — Integrated sa Next.js (walang hiwalay na terminal)

Ang setup na ito ay isasama DIRECTLY sa Next.js app mo. Gamit ang built-in
`instrumentation.ts` hook ni Next.js, awtomatikong sisimulan ang backup
scheduler paglabas/pag-start ng Next.js server mo — walang kailangang
hiwalay na `node scheduler.js` o kahit anong ibang terminal command
araw-araw. Basta naka-deploy/naka-run ang Next.js app mo (na kailangan mo
naman talaga), automatic na ang backup.

## 1. I-kopya ang mga files papunta sa Next.js project mo

```
your-nextjs-project/
├── instrumentation.ts          ← ilagay sa ROOT (kaparehong level ng next.config.js)
├── lib/
│   └── db-backup/
│       ├── mysqlBackup.js
│       ├── emailBackup.js
│       └── scheduler.js
```

Kung may `src/` folder ang project mo (src-based structure), ilagay ang
`instrumentation.ts` sa loob ng `src/` at ang `lib/db-backup/` din sa loob
ng `src/lib/db-backup/`.

## 2. I-install ang dependencies

```bash
npm install node-cron nodemailer archiver dotenv
```

## 3. I-enable ang instrumentation hook (kung Next.js 13.4 - 14.x)

Sa `next.config.js` mo, idagdag:

```js
module.exports = {
  experimental: {
    instrumentationHook: true,
  },
  // ...ibang config mo
};
```

**Next.js 15+**: hindi na kailangan nito, gumagana na agad.

## 4. Gawin ang `.env`

I-copy ang laman ng `.env.example` papunta sa `.env` (o `.env.local`) mo,
tapos lagyan ng totoong DB at Gmail credentials.

## 5. Gmail App Password (REQUIRED)

1. I-enable ang 2-Step Verification sa Google Account mo
2. Google Account → Security → 2-Step Verification → App Passwords
3. Gumawa ng App Password, ilagay sa `.env` bilang `GMAIL_APP_PASSWORD`

## 6. `mysqldump` CLI tool

Kailangan naka-install ito sa server. I-verify: `mysqldump --version`.
Kung hindi nasa PATH, i-set ang buong path via `MYSQLDUMP_PATH` sa `.env`.

## 7. Deploy / restart mo lang ang Next.js app — tapos na

```bash
npm run build
npm start
```

Kapag naka-start na, makikita mo sa logs:

```
[db-backup] Naka-schedule na ang daily backup (cron: "0 2 * * *", Asia/Manila)...
```

Mula dito, awtomatiko na — walang kailangan pang buksan na terminal
araw-araw. Basta naka-online lang ang Next.js app mo (parehong paraan ng
pagpapatakbo mo na dati, via pm2, Docker, systemd, o kahit ano man), tatakbo
ang backup + email nang naka-schedule.

## Mahalagang paalala

- **Dapat laging naka-running ang Next.js app mo** (production mode, `npm start`,
  hindi lang `npm run dev` na sinasara mo). Kung sarado ang app, hindi tatakbo
  ang scheduled backup — kaya kung meron kang existing deployment (pm2, Docker,
  VPS, atbp.), doon lang ito sasama, walang dagdag na proseso.
- Sa **serverless deployments** (Vercel, Netlify functions, atbp.), HINDI gagana
  ang paraang ito dahil walang laging-tumatakbong server process doon —
  kada request lang "nabubuhay" ang function. Kung Vercel/serverless ang setup
  mo, sabihin mo na lang para bigyan kita ng alternative (hal. external cron
  service na tumatawag sa isang API route).
- Ang backup file ay naka-save sa `BACKUP_DIR` (default: `./backups`) bago
  i-email — good idea na i-exclude ito sa git (`.gitignore`).

## Manual test (optional, hindi required)

Kung gusto mo lang subukan agad nang hindi hinihintay ang 2AM schedule,
pwede kang gumawa ng temporary test route sa Next.js app mo:

```js
// app/api/test-backup/route.js (App Router)
import { runBackupJob } from '@/lib/db-backup/scheduler';

export async function GET() {
  await runBackupJob();
  return Response.json({ status: 'done' });
}
```

Tapos i-visit mo lang sa browser: `http://localhost:3000/api/test-backup`.
Pwede mo nang tanggalin ang route na ito pagkatapos i-test.
